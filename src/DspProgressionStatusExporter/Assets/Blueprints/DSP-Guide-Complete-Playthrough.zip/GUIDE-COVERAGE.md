# Guide coverage — playthrough collection

**56 blueprints; all 21 production cards have their principal outputs represented.** The previously missing text-defined factories and optional lines are now included. The live published guide and local source matched when checked in hidden Chromium.

Use [the current collection index](README.md). Nine phase books contain 20 main-route blueprints; AUXILIARY contains 17; OPTIONAL contains 19. Source batch names and old first-test ZIPs are not the delivery classification.

## Resolved gaps

| Requirement | Current blueprint(s) |
|---|---|
| Foundation | [PHASES/BLUE/06-foundation.txt](PHASES/BLUE/06-foundation.txt) |
| Receiver, photons, antimatter reserve and hydrogen outlet | [PHASES/PHOTON/13-photon-antimatter.txt](PHASES/PHOTON/13-photon-antimatter.txt) |
| Mk.III proliferator | [AUXILIARY/01-proliferator.txt](AUXILIARY/01-proliferator.txt) |
| WARP Chemical Plant mall | [OPTIONAL/WARP/02-chemical-plants.txt](OPTIONAL/WARP/02-chemical-plants.txt) |
| SPHERE production and launch | [OPTIONAL/SPHERE/05-sphere-components.txt](OPTIONAL/SPHERE/05-sphere-components.txt), [OPTIONAL/SPHERE/07-carrier-rockets.txt](OPTIONAL/SPHERE/07-carrier-rockets.txt), [OPTIONAL/SPHERE/08-silo-mall.txt](OPTIONAL/SPHERE/08-silo-mall.txt), [OPTIONAL/SPHERE/14-rocket-launch.txt](OPTIONAL/SPHERE/14-rocket-launch.txt), [AUXILIARY/04-frame-material.txt](AUXILIARY/04-frame-material.txt), [AUXILIARY/06-deuteron-rods.txt](AUXILIARY/06-deuteron-rods.txt) |
| Orbital Collectors | [OPTIONAL/GAS-GIANT/11-orbital-collectors.txt](OPTIONAL/GAS-GIANT/11-orbital-collectors.txt) |
| Accumulator and exchanger malls and both power-shipping endpoints | [OPTIONAL/POWER/09-accumulator-mall.txt](OPTIONAL/POWER/09-accumulator-mall.txt), [OPTIONAL/POWER/10-exchanger-mall.txt](OPTIONAL/POWER/10-exchanger-mall.txt), [OPTIONAL/POWER/15-power-provider.txt](OPTIONAL/POWER/15-power-provider.txt), [OPTIONAL/POWER/16-power-receiver.txt](OPTIONAL/POWER/16-power-receiver.txt) |
| Advanced Mining Machine mall | [OPTIONAL/MINING/12-advanced-miners.txt](OPTIONAL/MINING/12-advanced-miners.txt) |

## Production-card coverage

| Guide card | Current blueprint(s) |
|---|---|
| [reference-electromagnetic-turbines](https://dsp-beginner-guide.pages.dev/#reference-electromagnetic-turbines) | [AUXILIARY/ils-04-turbines.txt](AUXILIARY/ils-04-turbines.txt) |
| [reference-graphene](https://dsp-beginner-guide.pages.dev/#reference-graphene) | [AUXILIARY/ils-05-graphene-standard.txt](AUXILIARY/ils-05-graphene-standard.txt), [AUXILIARY/ils-06-graphene-rare.txt](AUXILIARY/ils-06-graphene-rare.txt) |
| [card-bootstrap-mall-logistics](https://dsp-beginner-guide.pages.dev/#card-bootstrap-mall-logistics) | [PHASES/BLUE/02-mall-logistics.txt](PHASES/BLUE/02-mall-logistics.txt) |
| [card-bootstrap-mall-industry](https://dsp-beginner-guide.pages.dev/#card-bootstrap-mall-industry) | [PHASES/BLUE/05-mall-industry.txt](PHASES/BLUE/05-mall-industry.txt) |
| [card-bootstrap-mall-storage](https://dsp-beginner-guide.pages.dev/#card-bootstrap-mall-storage) | [PHASES/BLUE/03-mall-storage.txt](PHASES/BLUE/03-mall-storage.txt) |
| [card-bootstrap-mall-power](https://dsp-beginner-guide.pages.dev/#card-bootstrap-mall-power) | [PHASES/BLUE/04-mall-power.txt](PHASES/BLUE/04-mall-power.txt) |
| [card-blue-blue-cubes](https://dsp-beginner-guide.pages.dev/#card-blue-blue-cubes) | [PHASES/BLUE/01-blue-science.txt](PHASES/BLUE/01-blue-science.txt) |
| [card-red-red-cubes](https://dsp-beginner-guide.pages.dev/#card-red-red-cubes) | [PHASES/RED/01-red-science.txt](PHASES/RED/01-red-science.txt) |
| [card-red-security-mall](https://dsp-beginner-guide.pages.dev/#card-red-security-mall) | [PHASES/RED/02-security-turrets.txt](PHASES/RED/02-security-turrets.txt), [PHASES/RED/03-security-signals.txt](PHASES/RED/03-security-signals.txt), [PHASES/RED/04-security-missiles.txt](PHASES/RED/04-security-missiles.txt) |
| [card-yellow-yellow-cubes](https://dsp-beginner-guide.pages.dev/#card-yellow-yellow-cubes) | [PHASES/YELLOW/01-yellow-standard.txt](PHASES/YELLOW/01-yellow-standard.txt), [PHASES/YELLOW/02-yellow-rare.txt](PHASES/YELLOW/02-yellow-rare.txt) |
| [card-purple-processors](https://dsp-beginner-guide.pages.dev/#card-purple-processors) | [AUXILIARY/ils-03-processors.txt](AUXILIARY/ils-03-processors.txt), [AUXILIARY/purple-02-processors.txt](AUXILIARY/purple-02-processors.txt) |
| [card-purple-particle-broadband](https://dsp-beginner-guide.pages.dev/#card-purple-particle-broadband) | [AUXILIARY/purple-03-particle-broadband.txt](AUXILIARY/purple-03-particle-broadband.txt) |
| [card-green-quantum-chips](https://dsp-beginner-guide.pages.dev/#card-green-quantum-chips) | [PHASES/GREEN/01-quantum-chips.txt](PHASES/GREEN/01-quantum-chips.txt) |
| [card-green-graviton-lenses](https://dsp-beginner-guide.pages.dev/#card-green-graviton-lenses) | [PHASES/GREEN/02-graviton-lenses.txt](PHASES/GREEN/02-graviton-lenses.txt) |
| [card-dyson-solar-sails](https://dsp-beginner-guide.pages.dev/#card-dyson-solar-sails) | [PHASES/DYSON/01-sails-and-ejectors.txt](PHASES/DYSON/01-sails-and-ejectors.txt) |
| [card-dyson-em-rail-ejectors](https://dsp-beginner-guide.pages.dev/#card-dyson-em-rail-ejectors) | [PHASES/DYSON/01-sails-and-ejectors.txt](PHASES/DYSON/01-sails-and-ejectors.txt) |
| [card-sphere-dyson-components](https://dsp-beginner-guide.pages.dev/#card-sphere-dyson-components) | [OPTIONAL/SPHERE/05-sphere-components.txt](OPTIONAL/SPHERE/05-sphere-components.txt) |
| [card-sphere-deuteron-fuel-rods](https://dsp-beginner-guide.pages.dev/#card-sphere-deuteron-fuel-rods) | [AUXILIARY/06-deuteron-rods.txt](AUXILIARY/06-deuteron-rods.txt), [PHASES/GREEN/02-graviton-lenses.txt](PHASES/GREEN/02-graviton-lenses.txt) |
| [card-logistics-distribution-kit](https://dsp-beginner-guide.pages.dev/#card-logistics-distribution-kit) | [OPTIONAL/LOGISTICS/01-distribution-kit.txt](OPTIONAL/LOGISTICS/01-distribution-kit.txt) |
| [card-logistics-planetary-kit](https://dsp-beginner-guide.pages.dev/#card-logistics-planetary-kit) | [OPTIONAL/LOGISTICS/02-planetary-kit.txt](OPTIONAL/LOGISTICS/02-planetary-kit.txt) |
| [card-logistics-interstellar-kit](https://dsp-beginner-guide.pages.dev/#card-logistics-interstellar-kit) | [PHASES/ILS/01-ils-mall.txt](PHASES/ILS/01-ils-mall.txt), [OPTIONAL/LOGISTICS/03-interstellar-kit.txt](OPTIONAL/LOGISTICS/03-interstellar-kit.txt), [PHASES/ILS/02-vessel-mall.txt](PHASES/ILS/02-vessel-mall.txt) |

## Deliberate differences and remaining playthrough work

- Nominal science follows the agreed 40/min WHITE baseline: one BLUE, one RED, two YELLOW and two PURPLE tiles. A YELLOW tile is balanced for 20/min, below the guide reference of three labs at 22.5/min; two meet the late-game target.
- GREEN branches remain separate. Combine 20 chips/min and 20 lenses/min in eight standard labs for 40 green/min. Dedicated warpers add 7.5/min of each; PHOTON adds 0.4 lenses/min; rockets add 10 chips/min.
- The turret mall caps at one stack of 50; take eight for the initial deployment. The first pre-green 20 lenses to 20 warpers remains a manual Replicator batch.
- Photon nameplate requires lenses, full receiving/warmup and enough live Dyson generation. Allow about 1.656 GW at starting transmission efficiency; establish a 2000-antimatter reserve and sustain at least 40/min before WHITE. Keep hydrogen exporting.
- SPHERE supports 5 rockets/min and one matching unboosted silo. Components use 30 sails/min: full 405/min swarm supply plus rockets needs 435 sails/min. Budget shared inputs for every simultaneous consumer.
- Mining, extraction, EM ejector deployment, receiver siting, power generation, Dyson sphere/orbit design, logistics vehicles and non-mall hardware crafting remain normal gameplay. This is not a mall for every game building.
- All 56 saved layouts passed offline audits. Native codes are import/signature/hash verified. Receiver and exchanger rates and mode parameters passed isolated native-method checks. Planetary placement and sustained production await owner playthrough.

Reproduce: `review_guide_coverage.cjs`, `package_playthrough.py`, then `catalog_guide_coverage.py`. Repackage after refreshing coverage to include this report in the complete ZIP.
