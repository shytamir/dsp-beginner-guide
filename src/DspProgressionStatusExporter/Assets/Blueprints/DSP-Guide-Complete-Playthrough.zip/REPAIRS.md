# October playthrough repairs

This records the first October repair pass, which updated 29 phase/auxiliary blueprints. All 22 reported defects are now resolved by the owner's full collection playthrough on 2026-10-03: all blueprints deployed without defects and produced at the desired rates. The subsequent [collection-wide layout pass](DESIGN.md) includes the 19 untested optionals and supersedes some repaired geometries. Use the current collection; coordinates and counts below describe the historical repair snapshot where a later redesign applies. The original rejected sources and evidence remain preserved in the repository.

## What changed

- Tesla towers now respect the native 3.5 m minimum, with a 3.7 m design separation. Sorter coverage uses the actual first endpoint; newly covered consumers use a 10.2 m target inside the native 10.5 m radius. Neighboring tile seams and connected power networks are checked.
- Belt merges now assign a separate receiving slot to every branch. The game previously cleared one connection when another claimed the same slot. This affected RED, WHITE and the PHOTON antimatter block.
- RED science has two Mk.I hydrogen pickups per two-level lab stack. Its six refineries, 180 crude/min and 160 coal/min requirements, 40-cube target, oil outlet and hydrogen relief remain unchanged.
- GREEN lenses: the western hydrogen approach moves 0.30 grid away from the first collider. Its nearest ground-run clearance increases from 0.439 m to 0.816 m; the pickup retains its 90/min Mk.I reach setting.
- WHITE and DYSON: fragile corner ILS connectors move half a grid inward. Station settings, shipment minima and spray paths are preserved. WHITE still has a separate 312-facility, 32 x 28 lab section.

## Validation and limits

- Existing recipe, actual transport, collider, storage, technology, spraying and repeat-clearance audits pass for the affected layouts. All 37 phase/auxiliary layouts pass the corrected common rules.
- Native serialization, signatures and every field/connection round trip pass. All 37 phase/auxiliary blueprints retain every declared link when the installed game writes them in forward and reverse order. Original rejected files reproduce lost links: RED/01-red-science.txt (7), WHITE/01-white-40-into-research.txt (1), COMPLETION/13-photon-antimatter.txt (3).
- Native lab assembly and upward-transfer methods produce 400 red cubes in 10 measured minutes after a 2-minute startup, with finite idealized input delivery. This is a lab-mechanics test; it does not prove full in-game belt/sorter throughput or uniquely identify the original hydrogen bottleneck.
- WHITE station endpoints remain within the native 4 m limit under a 10% planar stretch check. That is a sensitivity check, not a spherical placement simulation. The exact latitude of the original failure is unknown.
- The subsequent layout pass checks all 19 optionals: nine redesigned, eight corrected for power/connections and two retained. All subsequently passed the owner's playthrough on 2026-10-03. OBS-001 oil reuse remains open; input contracts were not changed by the geometry pass.

## Original retest checklist — completed in owner playthrough

1. **RED science:** paste afresh, supply 180 crude/min and 160 coal/min, power it, and keep both product outlets open. Check every T merge and both upper labs; measure 40 cubes/min after startup.
2. **WHITE science:** paste near the equator and in the same second latitude band as the rejection. Check the two ILS connections and both white-cube branches feeding research. Copy the isolated lab section and join its seven feed belts.
3. **GREEN lenses:** confirm the western collider belt and Tesla pair now place, then verify hydrogen reaches the collider and the lens/fuel priority route operates.
4. **Remaining repaired tiles:** confirm placement, power every sorter, feed the listed raw/shared rates, check output after buffers settle, and test one repeat at the documented pitch.

Use the refreshed phase/AUXILIARY packs or the focused repair pack. Replace previous blueprint codes with these files for testing; rebuilding the old in-game footprint will retain the old defects. All current blueprints have since been accepted in the owner's playthrough (2026-10-03). Use the current complete collection; the repair-only ZIP is historical.

## Updated files

| Blueprint | Facilities before / after | Changes |
|---|---:|---|
| [BLUE Science - 40 per min](PHASES/BLUE/01-blue-science.txt) | 84 / 84 | power coverage/spacing |
| [BLUE Mall - Belts and Sorters](PHASES/BLUE/02-mall-logistics.txt) | 83 / 84 | power coverage/spacing |
| [BLUE Mall - Boxes and Tanks](PHASES/BLUE/03-mall-storage.txt) | 97 / 98 | power coverage/spacing |
| [BLUE Mall - Wind Tesla and Fuel](PHASES/BLUE/04-mall-power.txt) | 135 / 136 | power coverage/spacing |
| [BLUE Mall - Miners Smelters Assemblers](PHASES/BLUE/05-mall-industry.txt) | 261 / 264 | power coverage/spacing |
| [Carbon nanotubes - 120 per min](AUXILIARY/03-nanotubes.txt) | 498 / 499 | power coverage/spacing |
| [Frame material - 30 per min](AUXILIARY/04-frame-material.txt) | 870 / 872 | power coverage/spacing |
| [Deuteron fuel rods - 40 per min](AUXILIARY/06-deuteron-rods.txt) | 849 / 851 | power coverage/spacing |
| [PHOTON four receivers to 48 antimatter per min](PHASES/PHOTON/13-photon-antimatter.txt) | 496 / 499 | power coverage/spacing, belt merge slots |
| [DYSON 405 sails per min + capped ejector mall](PHASES/DYSON/01-sails-and-ejectors.txt) | 3846 / 3849 | power coverage/spacing, ILS reach margin |
| [BLUE Foundation - 15 per min](PHASES/BLUE/06-foundation.txt) | 49 / 50 | power coverage/spacing |
| [GREEN quantum chips - 20 per min](PHASES/GREEN/01-quantum-chips.txt) | 1491 / 1495 | power coverage/spacing |
| [GREEN lenses 20 and surplus fuel 4 per min](PHASES/GREEN/02-graviton-lenses.txt) | 1292 / 1295 | power coverage/spacing, collider clearance |
| [GREEN titanium crystals - 40 per min - standard](AUXILIARY/green-03-titanium-crystals-standard.txt) | 1421 / 1424 | power coverage/spacing |
| [YELLOW 20/min - organic crystals + kimberlite](PHASES/YELLOW/02-yellow-rare.txt) | 167 / 168 | power coverage/spacing |
| [Turbines 30/min - raw ores](AUXILIARY/ils-04-turbines.txt) | 548 / 548 | power coverage/spacing |
| [Graphene 60/min - standard](AUXILIARY/ils-05-graphene-standard.txt) | 293 / 294 | power coverage/spacing |
| [Titanium alloy 30/min - pumped acid](AUXILIARY/ils-08-alloy-rare.txt) | 182 / 183 | power coverage/spacing |
| [Particle containers 10/min - standalone standard](AUXILIARY/ils-09-containers-standard.txt) | 478 / 479 | power coverage/spacing |
| [Particle containers 10/min - standalone Fire Ice](AUXILIARY/ils-10-containers-rare.txt) | 483 / 486 | power coverage/spacing |
| [ILS 0.2/min - shared auxiliaries](PHASES/ILS/01-ils-mall.txt) | 185 / 185 | power coverage/spacing |
| [PURPLE science - 20 per min](PHASES/PURPLE/01-purple-science.txt) | 1692 / 1693 | power coverage/spacing |
| [PURPLE processors - 45 per min](AUXILIARY/purple-02-processors.txt) | 542 / 542 | power coverage/spacing |
| [PURPLE broadband - 22.5 per min](AUXILIARY/purple-03-particle-broadband.txt) | 688 / 689 | power coverage/spacing |
| [RED science - 40 per min](PHASES/RED/01-red-science.txt) | 269 / 274 | power coverage/spacing, belt merge slots, hydrogen pickups |
| [RED security - missile turrets from ores](PHASES/RED/02-security-turrets.txt) | 156 / 157 | power coverage/spacing |
| [RED security - signal towers from stone and ores](PHASES/RED/03-security-signals.txt) | 193 / 194 | power coverage/spacing |
| [RED security - 10 missile sets per min](PHASES/RED/04-security-missiles.txt) | 192 / 194 | power coverage/spacing |
| [WHITE 40 per min into research](PHASES/WHITE/01-white-40-into-research.txt) | 686 / 686 | belt merge slots, ILS reach margin |
