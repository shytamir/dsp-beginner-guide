# Collection layout review — October 2026

**All 56 blueprints reviewed, including all 19 optionals.** Twenty-five factories were redesigned; eight additional optional layouts received power or station-connection corrections. Twenty-three retain their repaired baseline layout. All 56 blueprints subsequently passed owner playthrough on 2026-10-03, deployed without defects and producing at the desired rates.

Use the current complete collection and individual books. The earlier repair-only ZIP is historical: this pass supersedes some of its layouts. Production targets, raw/shared inputs, recipes, machine tiers, stock caps, spraying intent and ILS shipment minima remain unchanged.

## Design rules

- Place machines with identical recipes and matching input/output sets together in aligned rows. Give each row continuous straight material lanes, with matching sorter positions. Separate unlike recipes and different buffer roles.
- Pack recipe rows in dependency order. Route between nearby blocks; finish a shared row before visiting another one. Reserve clearance for buildings, power, sorters and elevated crossings.
- Evaluate the serialized layout: footprint area must not grow, physical belt length must fall by more than 3%, and neither horizontal bends nor rising/falling belt edges may increase. A smaller rectangle alone does not qualify.
- Use Super Magnetic Field Generator (technology 1711) for one-grid ramps in the 25 redesigns. This is the agreed explicit assumption from ILS onward; the native PLS/ILS prerequisite chain does not itself require it. Their setup sheets and blueprint descriptions name this requirement.
- Preserve useful access and the requested form factors. BLUE/RED keep their early square layouts; PURPLE and the Mk.III assembler mall retain the square constraint. WHITE keeps its isolated 32×28, 312-facility lab copy section. The dedicated warper factory remains intentionally non-tileable.

## Measured redesigns

Comparisons use the repaired collection immediately before this design pass. Belt length is the sum of physical belt-to-belt edges in the saved records, including slopes; station-internal connector lengths are excluded on both sides. Area is the enclosing grid rectangle, not occupied-machine area. Some small factories have no repeated recipe to group; they still benefit from shorter routing.

| Blueprint | Grid before → after | Area saved | Belt length, m before → after | Belt saved | Bends before → after | Facilities before → after |
|---|---|---:|---:|---:|---:|---:|
| [Mk.III proliferator - 120 per min](AUXILIARY/01-proliferator.md) | 91×52 → 59×49 | 38.9% | 2042.8 → 1117.7 | 45.3% | 218 → 56 | 1701 → 968 |
| [WARP Chemical Plant mall - 2 per min](OPTIONAL/WARP/02-chemical-plants.md) | 65×56 → 44×37 | 55.3% | 1096.4 → 785.5 | 28.4% | 146 → 59 | 921 → 657 |
| [Carbon nanotubes - 120 per min](AUXILIARY/03-nanotubes.md) | 62×41 → 54×28 | 40.5% | 589.3 → 422.9 | 28.2% | 76 → 19 | 499 → 366 |
| [Frame material - 30 per min](AUXILIARY/04-frame-material.md) | 69×48 → 54×44 | 28.3% | 1036.2 → 699.2 | 32.5% | 101 → 40 | 872 → 607 |
| [SPHERE components - 10 per min](OPTIONAL/SPHERE/05-sphere-components.md) | 71×60 → 54×56 | 29.0% | 1427.5 → 917.9 | 35.7% | 166 → 47 | 1193 → 790 |
| [Deuteron fuel rods - 40 per min](AUXILIARY/06-deuteron-rods.md) | 61×52 → 42×28 | 62.9% | 1014.1 → 793.0 | 21.8% | 118 → 53 | 851 → 660 |
| [SPHERE carrier rockets - 5 per min](OPTIONAL/SPHERE/07-carrier-rockets.md) | 58×32 → 30×18 | 70.9% | 319.9 → 211.6 | 33.9% | 22 → 11 | 271 → 181 |
| [SPHERE silo mall - 1 per 5 min](OPTIONAL/SPHERE/08-silo-mall.md) | 58×36 → 36×20 | 65.5% | 407.4 → 260.3 | 36.1% | 51 → 17 | 344 → 223 |
| [Accumulator mall - 10 per min](OPTIONAL/POWER/09-accumulator-mall.md) | 65×60 → 51×32 | 58.2% | 1104.5 → 864.0 | 21.8% | 147 → 54 | 929 → 726 |
| [Energy Exchanger mall - 1 per 2 min](OPTIONAL/POWER/10-exchanger-mall.md) | 58×44 → 37×27 | 60.9% | 630.2 → 409.5 | 35.0% | 82 → 24 | 532 → 348 |
| [Orbital Collector mall - 1 per 5 min](OPTIONAL/GAS-GIANT/11-orbital-collectors.md) | 61×60 → 42×32 | 63.3% | 1017.8 → 729.3 | 28.3% | 155 → 49 | 856 → 614 |
| [Advanced Miner mall - 1 per 2 min](OPTIONAL/MINING/12-advanced-miners.md) | 58×60 → 45×32 | 58.6% | 922.7 → 660.3 | 28.4% | 132 → 35 | 778 → 557 |
| [DYSON 405 sails per min + capped ejector mall](PHASES/DYSON/01-sails-and-ejectors.md) | 177×80 → 127×60 | 46.2% | 4537.1 → 2837.0 | 37.5% | 564 → 136 | 3849 → 2505 |
| [Pile sorter mall - 15 per min](OPTIONAL/PILE-SORTER/02-pile-sorter-mall.md) | 52×52 → 40×48 | 29.0% | 728.9 → 565.5 | 22.4% | 83 → 34 | 621 → 484 |
| [GREEN quantum chips - 20 per min](PHASES/GREEN/01-quantum-chips.md) | 81×40 → 50×61 | 5.9% | 1716.7 → 1030.2 | 40.0% | 312 → 54 | 1495 → 961 |
| [GREEN lenses 20 and surplus fuel 4 per min](PHASES/GREEN/02-graviton-lenses.md) | 80×41 → 52×62 | 1.7% | 1472.9 → 1202.1 | 18.4% | 264 → 74 | 1295 → 1074 |
| [GREEN titanium crystals - 40 per min - standard](AUXILIARY/green-03-titanium-crystals-standard.md) | 81×42 → 52×59 | 9.8% | 1651.7 → 1073.4 | 35.0% | 277 → 48 | 1424 → 975 |
| [GREEN titanium crystals - 40 per min - organic crystals](AUXILIARY/green-04-titanium-crystals-rare.md) | 47×23 → 36×27 | 10.1% | 240.5 → 155.9 | 35.2% | 50 → 4 | 227 → 162 |
| [YELLOW 20/min - organic crystals + kimberlite](PHASES/YELLOW/02-yellow-rare.md) | 30×32 → 33×27 | 7.2% | 173.8 → 143.2 | 17.6% | 46 → 6 | 168 → 145 |
| [Processors 40/min - raw ores](AUXILIARY/ils-03-processors.md) | 45×38 → 57×27 | 10.0% | 531.3 → 456.1 | 14.2% | 116 → 20 | 490 → 436 |
| [Turbines 30/min - raw ores](AUXILIARY/ils-04-turbines.md) | 43×40 → 38×38 | 16.0% | 611.5 → 367.9 | 39.8% | 146 → 18 | 548 → 361 |
| [Titanium alloy 30/min - pumped acid](AUXILIARY/ils-08-alloy-rare.md) | 30×29 → 32×26 | 4.4% | 188.9 → 143.1 | 24.3% | 43 → 10 | 183 → 146 |
| [Particle containers 10/min - standalone Fire Ice](AUXILIARY/ils-10-containers-rare.md) | 39×40 → 36×38 | 12.3% | 536.9 → 382.7 | 28.7% | 111 → 28 | 486 → 360 |
| [Vessels 0.5/min - shared auxiliaries](PHASES/ILS/02-vessel-mall.md) | 30×16 → 23×17 | 18.5% | 78.7 → 72.8 | 7.4% | 10 → 4 | 77 → 72 |
| [PURPLE science - 20 per min](PHASES/PURPLE/01-purple-science.md) | 63×63 → 60×60 | 9.3% | 1946.7 → 1313.5 | 32.5% | 341 → 67 | 1693 → 1201 |

## Other optional corrections

These keep their existing factory arrangement and production contract.

| Blueprint | Correction |
|---|---|
| [POWER charging terminal - 54 MW](OPTIONAL/POWER/15-power-provider.md) | 2 ILS belt endpoints pulled inward for reach margin |
| [POWER balanced receiving terminal - 54 MW](OPTIONAL/POWER/16-power-receiver.md) | 4 ILS belt endpoints pulled inward for reach margin |
| [Dedicated ILS warpers - 120 per min](OPTIONAL/WARP/01-dedicated-warpers.md) | 4 ILS belt endpoints pulled inward for reach margin |
| [LOGISTICS - distributors and bots](OPTIONAL/LOGISTICS/01-distribution-kit.md) | Power coverage and tower spacing: 1 tower placements adjusted or added |
| [LOGISTICS - PLS and drones](OPTIONAL/LOGISTICS/02-planetary-kit.md) | Power coverage and tower spacing: 3 tower placements adjusted or added |
| [LOGISTICS - ILS and vessels](OPTIONAL/LOGISTICS/03-interstellar-kit.md) | Power coverage and tower spacing: 1 tower placements adjusted or added |
| [LOGISTICS - Mk.I to Mk.III belts](OPTIONAL/LOGISTICS/04-upgrade-belts.md) | Power coverage and tower spacing: 1 tower placements adjusted or added |
| [LOGISTICS - Mk.I to Mk.III sorters](OPTIONAL/LOGISTICS/05-upgrade-sorters.md) | Power coverage and tower spacing: 1 tower placements adjusted or added |

## Retained layouts

These were included in the common rule/contract checks and measurements. Small or specialized layouts keep their existing arrangement; unsuccessful row candidates were not promoted. The two retained optionals are the Mk.III assembler mall and the silo launch block.

| Blueprint | Reason to retain |
|---|---|
| [BLUE Science - 40 per min](PHASES/BLUE/01-blue-science.md) | Early research/count gate; compact square baseline, no steep-belt assumption |
| [BLUE Mall - Belts and Sorters](PHASES/BLUE/02-mall-logistics.md) | Early research/count gate; compact square baseline, no steep-belt assumption |
| [BLUE Mall - Boxes and Tanks](PHASES/BLUE/03-mall-storage.md) | Early research/count gate; compact square baseline, no steep-belt assumption |
| [BLUE Mall - Wind Tesla and Fuel](PHASES/BLUE/04-mall-power.md) | Early research/count gate; compact square baseline, no steep-belt assumption |
| [BLUE Mall - Miners Smelters Assemblers](PHASES/BLUE/05-mall-industry.md) | Early research/count gate; compact square baseline, no steep-belt assumption |
| [PHOTON four receivers to 48 antimatter per min](PHASES/PHOTON/13-photon-antimatter.md) | Specialized receiver/launch block; existing service arrangement retained |
| [SPHERE rocket launch - 5 per min](OPTIONAL/SPHERE/14-rocket-launch.md) | Specialized receiver/launch block; existing service arrangement retained |
| [BLUE Foundation - 15 per min](PHASES/BLUE/06-foundation.md) | Early research/count gate; compact square baseline, no steep-belt assumption |
| [YELLOW 20/min - standard](PHASES/YELLOW/01-yellow-standard.md) | No audited row candidate passed all area, belt, bend and ramp gates |
| [Graphene 60/min - standard](AUXILIARY/ils-05-graphene-standard.md) | No audited row candidate passed all area, belt, bend and ramp gates |
| [Graphene 60/min - Fire Ice](AUXILIARY/ils-06-graphene-rare.md) | No audited row candidate passed all area, belt, bend and ramp gates |
| [Titanium alloy 30/min - standard](AUXILIARY/ils-07-alloy-standard.md) | No audited row candidate passed all area, belt, bend and ramp gates |
| [Particle containers 10/min - standalone standard](AUXILIARY/ils-09-containers-standard.md) | No audited row candidate passed all area, belt, bend and ramp gates |
| [ILS 0.2/min - shared auxiliaries](PHASES/ILS/01-ils-mall.md) | No audited row candidate passed all area, belt, bend and ramp gates |
| [Particle containers 10/min - shared auxiliaries](AUXILIARY/ils-13-containers-shared.md) | No audited row candidate passed all area, belt, bend and ramp gates |
| [LOGISTICS - Mk.I to Mk.III assemblers](OPTIONAL/LOGISTICS/06-upgrade-assemblers.md) | No audited row candidate passed all area, belt, bend and ramp gates |
| [PURPLE processors - 45 per min](AUXILIARY/purple-02-processors.md) | No audited row candidate passed all area, belt, bend and ramp gates |
| [PURPLE broadband - 22.5 per min](AUXILIARY/purple-03-particle-broadband.md) | No audited row candidate passed all area, belt, bend and ramp gates |
| [RED science - 40 per min](PHASES/RED/01-red-science.md) | Early research/count gate; compact square baseline, no steep-belt assumption |
| [RED security - missile turrets from ores](PHASES/RED/02-security-turrets.md) | Early research/count gate; compact square baseline, no steep-belt assumption |
| [RED security - signal towers from stone and ores](PHASES/RED/03-security-signals.md) | Early research/count gate; compact square baseline, no steep-belt assumption |
| [RED security - 10 missile sets per min](PHASES/RED/04-security-missiles.md) | Early research/count gate; compact square baseline, no steep-belt assumption |
| [WHITE 40 per min into research](PHASES/WHITE/01-white-40-into-research.md) | Deliberate ILS clearance and separately copyable lab rectangle |

## Validation and playthrough limits

- All 56 saved layouts pass common power coverage, tower and repeat spacing, station reach and directed-join checks. Machine/recipe/settings inventories, raw draw, shared input contracts and storage capacities match the repaired baseline. The existing full batch audits cover transport, collisions, spray paths and construction limits.
- Redesigned shared lanes are checked in the actual serialized belt graph. A negative test breaks an interior link and is rejected; another removes the steep-belt research declaration and is rejected.
- All 56 codes import with valid signatures and matching manifests. All declared connections survive the installed game's native connection writer in both build orders. Rejected historical RED/WHITE/PHOTON fixtures still reproduce lost links. The native RED lab test retains its 40/min result with idealized finite input timing.
- Validation is offline against 0.10.35.29104. It does not run Unity placement physics, simulate a spherical latitude band, or establish sustained belt/sorter production in game. Subsequent owner playthrough confirmed deployment without defects and desired production rates across all 56 blueprints (2026-10-03).
- OBS-001, sharing RED refined-oil surplus with later lines, remains a separate open balance question. This pass does not silently change any factory's input contract.

Evidence: [all 56 measurements and contract checks](validation/layout-quality.json), [optional correction record](validation/optional-rule-checks.json), [native connection checks](validation/native-repair-tests.json), [native import checks](validation/complete-native-import.json), [negative row tests](validation/recipe-row-negative-tests.json).

The completed owner retest covered RED hydrogen delivery, WHITE's ILS connections in the previously failing latitude band, GREEN collider clearance, and the redesigned sail/ejector layout. The updated AUX and optional factories were also accepted at their desired rates.
