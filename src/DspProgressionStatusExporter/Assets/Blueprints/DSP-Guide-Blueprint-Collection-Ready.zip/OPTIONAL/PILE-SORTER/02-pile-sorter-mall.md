# Pile sorter mall - 15 per min

[Blueprint text](02-pile-sorter-mall.txt) · [Layout preview](previews/02-pile-sorter-mall.png)

Inputs: Iron ore 45/m; Coal 30/m; Turbines 30/m; Processors 15/m; Mk.III sorters 30/m.

Outputs: Pile sorters 15/m.

Notes: Stock caps: Pile sorters 200. Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
