# SPHERE components - 10 per min

[Blueprint text](05-sphere-components.txt) · [Layout preview](previews/05-sphere-components.png)

Inputs: Graphene 180/m; Titanium ore 120/m; Titanium alloy 30/m; Silicon ore 60/m; Solar sails 30/m; Processors 30/m.

Outputs: Sphere components 10/m.

Notes: Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
