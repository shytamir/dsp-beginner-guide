# SPHERE rocket launch - 5 per min

[Blueprint text](14-rocket-launch.txt) · [Layout preview](previews/14-rocket-launch.png)

Inputs: Carrier rockets 5/m.

Outputs: Rocket launches 5/m.

Notes: Add nodes or frames in the Dyson Sphere editor to receive launches. Launching pauses when no structure points are requested. Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
