# SPHERE carrier rockets - 5 per min

[Blueprint text](07-carrier-rockets.txt) · [Layout preview](previews/07-carrier-rockets.png)

Inputs: Sphere components 10/m; Deuteron fuel rods 20/m; Quantum chips 10/m.

Outputs: Carrier rockets 5/m.

Notes: Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
