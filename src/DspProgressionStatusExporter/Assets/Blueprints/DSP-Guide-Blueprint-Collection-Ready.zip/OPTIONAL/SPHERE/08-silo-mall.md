# SPHERE silo mall - 1 per 5 min

[Blueprint text](08-silo-mall.txt) · [Layout preview](previews/08-silo-mall.png)

Inputs: Titanium alloy 16/m; Frame material 6/m; Graviton lenses 4/m; Quantum chips 2/m.

Outputs: Launching silos 0.2/m.

Notes: Stock caps: Launching silos 10. Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
