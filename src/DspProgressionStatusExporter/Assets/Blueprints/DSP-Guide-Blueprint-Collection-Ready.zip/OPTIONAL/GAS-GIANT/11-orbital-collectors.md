# Orbital Collector mall - 1 per 5 min

[Blueprint text](11-orbital-collectors.txt) · [Layout preview](previews/11-orbital-collectors.png)

Inputs: ILS 0.2/m; Turbines 40/m; Iron ore 30/m; Coal 20/m; Titanium alloy 20/m; Full accumulators 4/m.

Outputs: Orbital Collectors 0.2/m.

Notes: Stock caps: Orbital Collectors 40. Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
