# Advanced Miner mall - 1 per 2 min

[Blueprint text](12-advanced-miners.txt) · [Layout preview](previews/12-advanced-miners.png)

Inputs: Titanium alloy 10/m; Frame material 5/m; Turbines 10/m; Iron ore 15/m; Coal 10/m; Quantum chips 2/m; Optical grating crystals 20/m.

Outputs: Advanced Miners 0.5/m.

Notes: Stock caps: Advanced Miners 30. Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
