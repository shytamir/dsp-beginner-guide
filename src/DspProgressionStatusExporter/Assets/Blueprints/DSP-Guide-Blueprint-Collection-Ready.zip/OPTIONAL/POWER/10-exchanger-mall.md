# Energy Exchanger mall - 1 per 2 min

[Blueprint text](10-exchanger-mall.txt) · [Layout preview](previews/10-exchanger-mall.png)

Inputs: Titanium alloy 20/m; Iron ore 60/m; Processors 20/m; Particle containers 4/m.

Outputs: Energy Exchangers 0.5/m.

Notes: Stock caps: Energy Exchangers 20. Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
