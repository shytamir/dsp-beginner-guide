# POWER charging terminal - 54 MW

[Blueprint text](15-power-provider.txt) · [Layout preview](previews/15-power-provider.png)

Inputs: Empty accumulators 6/m.

Outputs: Full accumulators 6/m.

Notes: Charging uses 54 MW of surplus power, plus up to 6 MW for ILS charging. Seed the accumulator loop and provide startup power. Full accumulators supply both local and remote consumers. Load drones/vessels and warpers as needed for logistics.
