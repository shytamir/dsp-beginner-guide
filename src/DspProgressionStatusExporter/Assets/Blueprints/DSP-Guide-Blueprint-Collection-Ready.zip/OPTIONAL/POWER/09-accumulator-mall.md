# Accumulator mall - 10 per min

[Blueprint text](09-accumulator-mall.txt) · [Layout preview](previews/09-accumulator-mall.png)

Inputs: Iron ore 90/m; Turbines 20/m; Coal 20/m; Silicon ore 60/m.

Outputs: Empty accumulators 10/m.

Notes: Stock caps: Empty accumulators 1,000. Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
