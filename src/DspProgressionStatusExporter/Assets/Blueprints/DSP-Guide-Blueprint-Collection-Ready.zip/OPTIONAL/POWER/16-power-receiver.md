# POWER balanced receiving terminal - 54 MW

[Blueprint text](16-power-receiver.txt) · [Layout preview](previews/16-power-receiver.png)

Inputs: Full accumulators 6/m.

Outputs: Empty accumulators 6/m.

Notes: Delivers up to 54 MW gross; ILS charging can use up to 6 MW. Seed both accumulator stocks and provide startup power. Surplus discharge is recharged locally; net accumulator imports fall with demand. Allow the loop to settle before expanding it. Load drones/vessels and warpers as needed for logistics.
