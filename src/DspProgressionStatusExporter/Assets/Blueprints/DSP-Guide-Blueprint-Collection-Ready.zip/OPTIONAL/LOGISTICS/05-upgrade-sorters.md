# LOGISTICS - Mk.I to Mk.III sorters

[Blueprint text](05-upgrade-sorters.txt) · [Layout preview](previews/05-upgrade-sorters.png)

Inputs: Copper ore 7.5/m; Iron ore 60/m; Mk.I sorters 30/m; Turbines 15/m.

Outputs: Mk.III sorters 30/m.

Notes: Stock caps: Mk.III sorters 400.
