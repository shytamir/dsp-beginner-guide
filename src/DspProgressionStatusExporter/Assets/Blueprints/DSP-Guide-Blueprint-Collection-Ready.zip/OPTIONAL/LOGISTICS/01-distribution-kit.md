# LOGISTICS - distributors and bots

[Blueprint text](01-distribution-kit.txt) · [Layout preview](previews/01-distribution-kit.png)

Inputs: Iron ore 72/m; Copper ore 36/m; Stone 48/m; Processors 16/m.

Outputs: Distributors 2/m; Bots 8/m.

Notes: Stock caps: Distributors 50; Bots 200.
