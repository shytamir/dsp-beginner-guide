# LOGISTICS - Mk.I to Mk.III belts

[Blueprint text](04-upgrade-belts.txt) · [Layout preview](previews/04-upgrade-belts.png)

Inputs: Mk.I belts 60/m; Iron ore 60/m; Graphene 20/m; Coal 40/m; Turbines 60/m.

Outputs: Mk.III belts 60/m.

Notes: Stock caps: Mk.III belts 900.
