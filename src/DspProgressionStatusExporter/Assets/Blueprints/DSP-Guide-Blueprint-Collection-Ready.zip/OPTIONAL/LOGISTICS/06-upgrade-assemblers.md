# LOGISTICS - Mk.I to Mk.III assemblers

[Blueprint text](06-upgrade-assemblers.txt) · [Layout preview](previews/06-upgrade-assemblers.png)

Inputs: Crude oil 96/m; Graphene 40/m; Processors 8/m; Water 12/m; Silicon ore 32/m; Titanium ore 56/m; Stone 16/m; Coal 32/m; Mk.I assemblers 1/m.

Outputs: Mk.III assemblers 1/m; Refined oil 60/m.

Notes: Keep refined-oil and hydrogen relief outlets clear. With production stopped and enough crude supplied, relief can reach 120/m refined oil and 60/m hydrogen. Stock caps: Mk.III assemblers 50.
