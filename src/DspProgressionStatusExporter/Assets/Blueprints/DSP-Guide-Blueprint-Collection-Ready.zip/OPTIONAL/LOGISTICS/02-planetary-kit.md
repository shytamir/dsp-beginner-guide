# LOGISTICS - PLS and drones

[Blueprint text](02-planetary-kit.txt) · [Layout preview](previews/02-planetary-kit.png)

Inputs: Iron ore 230/m; Copper ore 60/m; Titanium ore 40/m; Particle containers 10/m; Processors 40/m.

Outputs: PLS 0.5/m; Drones 10/m.

Notes: Stock caps: Drones 200; PLS 10.
