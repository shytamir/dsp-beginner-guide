# LOGISTICS - ILS and vessels

[Blueprint text](03-interstellar-kit.txt) · [Layout preview](previews/03-interstellar-kit.png)

Inputs: PLS 0.2/m; Particle containers 4/m; Turbines 10/m; Processors 10/m; Titanium alloy 28/m.

Outputs: ILS 0.2/m; Vessels 1/m.

Notes: Stock caps: ILS 10; Vessels 50.
