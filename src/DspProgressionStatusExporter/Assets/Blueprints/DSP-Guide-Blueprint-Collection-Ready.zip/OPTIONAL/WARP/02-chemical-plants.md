# WARP Chemical Plant mall - 2 per min

[Blueprint text](02-chemical-plants.txt) · [Layout preview](previews/02-chemical-plants.png)

Inputs: Iron ore 52/m; Stone 48/m; Copper ore 2/m.

Outputs: Chemical Plants 2/m.

Notes: Stock caps: Chemical Plants 30. Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
