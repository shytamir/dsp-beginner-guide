# Dedicated ILS warpers - 120 per min

[Blueprint text](01-dedicated-warpers.txt) · [Layout preview](previews/01-dedicated-warpers.png)

Inputs: Graviton lenses 7.5/m; Quantum chips 7.5/m.

Outputs: Space warpers 120/m.

Notes: Warper stock is capped at 4,000, available for local and remote supply. Optional: supply Mk.III proliferator. Listed rates exclude its bonus. Load drones/vessels and warpers as needed for logistics.
