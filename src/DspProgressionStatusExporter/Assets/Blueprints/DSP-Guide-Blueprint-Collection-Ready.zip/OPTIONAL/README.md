# OPTIONAL

19 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [Orbital Collector mall - 1 per 5 min](GAS-GIANT/11-orbital-collectors.md)
- [LOGISTICS - distributors and bots](LOGISTICS/01-distribution-kit.md)
- [LOGISTICS - PLS and drones](LOGISTICS/02-planetary-kit.md)
- [LOGISTICS - ILS and vessels](LOGISTICS/03-interstellar-kit.md)
- [LOGISTICS - Mk.I to Mk.III belts](LOGISTICS/04-upgrade-belts.md)
- [LOGISTICS - Mk.I to Mk.III sorters](LOGISTICS/05-upgrade-sorters.md)
- [LOGISTICS - Mk.I to Mk.III assemblers](LOGISTICS/06-upgrade-assemblers.md)
- [Advanced Miner mall - 1 per 2 min](MINING/12-advanced-miners.md)
- [Pile sorter mall - 15 per min](PILE-SORTER/02-pile-sorter-mall.md)
- [Accumulator mall - 10 per min](POWER/09-accumulator-mall.md)
- [Energy Exchanger mall - 1 per 2 min](POWER/10-exchanger-mall.md)
- [POWER charging terminal - 54 MW](POWER/15-power-provider.md)
- [POWER balanced receiving terminal - 54 MW](POWER/16-power-receiver.md)
- [SPHERE components - 10 per min](SPHERE/05-sphere-components.md)
- [SPHERE carrier rockets - 5 per min](SPHERE/07-carrier-rockets.md)
- [SPHERE silo mall - 1 per 5 min](SPHERE/08-silo-mall.md)
- [SPHERE rocket launch - 5 per min](SPHERE/14-rocket-launch.md)
- [Dedicated ILS warpers - 120 per min](WARP/01-dedicated-warpers.md)
- [WARP Chemical Plant mall - 2 per min](WARP/02-chemical-plants.md)
