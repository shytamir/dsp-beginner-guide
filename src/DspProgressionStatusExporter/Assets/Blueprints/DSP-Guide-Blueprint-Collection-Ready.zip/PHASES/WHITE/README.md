# PHASES/WHITE

1 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [WHITE 40 per min into research](01-white-40-into-research.md)
