# WHITE 40 per min into research

[Blueprint text](01-white-40-into-research.txt) · [Layout preview](previews/01-white-40-into-research.png)

Inputs: Blue cubes 40/m; Red cubes 40/m; Yellow cubes 40/m; Purple cubes 40/m; Green cubes 40/m; Antimatter 40/m.

Outputs: White cubes 40/m into research (36,000 hashes/m at the Mission Completed baseline).

Notes: White cubes are consumed on site, not exported. Queue white-cube research. When expanding, copy the separated lab block without the ILS and extend its feed belts. Optional: supply Mk.III proliferator. Listed rates exclude its bonus. Load drones/vessels and warpers as needed for logistics.
