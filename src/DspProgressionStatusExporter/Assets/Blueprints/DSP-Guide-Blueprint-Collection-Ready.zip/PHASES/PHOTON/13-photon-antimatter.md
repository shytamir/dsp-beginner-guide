# PHOTON four receivers to 48 antimatter per min

[Blueprint text](13-photon-antimatter.txt) · [Layout preview](previews/13-photon-antimatter.png)

Inputs: Graviton lenses 0.4/m.

Outputs: Antimatter 48/m; Hydrogen 48/m.

Notes: Output assumes fully warmed receivers with continuous reception. At starting transmission efficiency, allow 1.656 GW of dedicated Dyson generation. Keep hydrogen exporting. Temporarily disconnect the antimatter outlet to build the 2,000-item reserve before feeding WHITE. Optional spraying can raise photon supply above the 60/m conversion limit. Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
