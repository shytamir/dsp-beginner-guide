# PHASES/PHOTON

1 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [PHOTON four receivers to 48 antimatter per min](13-photon-antimatter.md)
