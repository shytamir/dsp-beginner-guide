# BLUE Mall - Wind Tesla and Fuel

[Blueprint text](04-mall-power.txt) · [Layout preview](previews/04-mall-power.png)

Inputs: Coal 45/m; Copper ore 12.5/m; Iron ore 80/m.

Outputs: Wind turbines 5/m; Tesla towers 10/m; Combustible units 15/m.

Notes: Stock caps: 50 wind turbines, 100 Tesla towers and 200 combustible units.
