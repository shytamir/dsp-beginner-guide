# BLUE Science - 40 per min

[Blueprint text](01-blue-science.txt) · [Layout preview](previews/01-blue-science.png)

Inputs: Copper ore 40/m; Iron ore 80/m.

Outputs: Blue cubes 40/m.
