# PHASES/BLUE

6 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [BLUE Science - 40 per min](01-blue-science.md)
- [BLUE Mall - Belts and Sorters](02-mall-logistics.md)
- [BLUE Mall - Boxes and Tanks](03-mall-storage.md)
- [BLUE Mall - Wind Tesla and Fuel](04-mall-power.md)
- [BLUE Mall - Miners Smelters Assemblers](05-mall-industry.md)
- [BLUE Foundation - 15 per min](06-foundation.md)
