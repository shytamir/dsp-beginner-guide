# BLUE Foundation - 15 per min

[Blueprint text](06-foundation.txt) · [Layout preview](previews/06-foundation.png)

Inputs: Iron ore 45/m; Stone 45/m.

Outputs: Foundation 15/m.

Notes: Stock caps: Foundation 1,000.
