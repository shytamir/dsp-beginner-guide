# BLUE Mall - Boxes and Tanks

[Blueprint text](03-mall-storage.txt) · [Layout preview](previews/03-mall-storage.png)

Inputs: Stone 80/m; Iron ore 60/m.

Outputs: Storage Mk.I 5/m; Storage tanks 5/m.

Notes: Stock caps: 50 Storage Mk.I and 50 storage tanks.
