# BLUE Mall - Belts and Sorters

[Blueprint text](02-mall-logistics.txt) · [Layout preview](previews/02-mall-logistics.png)

Inputs: Copper ore 15/m; Iron ore 120/m.

Outputs: Mk.I belts 60/m; Mk.I sorters 30/m.

Notes: Stock caps: 900 Mk.I belts and 400 Mk.I sorters.
