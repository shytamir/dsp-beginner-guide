# BLUE Mall - Miners Smelters Assemblers

[Blueprint text](05-mall-industry.txt) · [Layout preview](previews/05-mall-industry.png)

Inputs: Stone 10/m; Copper ore 35/m; Iron ore 180/m.

Outputs: Mining machines 5/m; Arc smelters 5/m; Mk.I assemblers 5/m.

Notes: Stock caps: 50 of each building.
