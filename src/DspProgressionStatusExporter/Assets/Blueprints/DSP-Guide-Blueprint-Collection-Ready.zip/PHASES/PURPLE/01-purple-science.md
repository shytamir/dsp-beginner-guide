# PURPLE science - 20 per min

[Blueprint text](01-purple-science.txt) · [Layout preview](previews/01-purple-science.png)

Inputs: Iron ore 80/m; Copper ore 120/m; Silicon ore 400/m; Graphene 60/m; Titanium ore 40/m; Crude oil 40/m; Coal 40/m.

Outputs: Purple cubes 20/m; Hydrogen 20/m.

Notes: Split silicon ore evenly between the two inputs: 200/m each. Keep hydrogen and refined-oil relief outlets clear; with production stopped and enough crude supplied, relief can reach 30/m hydrogen and 60/m refined oil.
