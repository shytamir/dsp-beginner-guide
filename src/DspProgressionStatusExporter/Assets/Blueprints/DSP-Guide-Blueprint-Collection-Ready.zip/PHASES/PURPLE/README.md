# PHASES/PURPLE

1 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [PURPLE science - 20 per min](01-purple-science.md)
