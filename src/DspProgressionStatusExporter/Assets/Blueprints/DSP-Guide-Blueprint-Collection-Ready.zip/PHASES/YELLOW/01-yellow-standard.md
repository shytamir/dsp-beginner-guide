# YELLOW 20/min - standard

[Blueprint text](01-yellow-standard.txt) · [Layout preview](previews/01-yellow-standard.png)

Inputs: Coal 120/m; Crude oil 100/m; Water 20/m; Titanium ore 120/m.

Outputs: Yellow cubes 20/m; Hydrogen 50/m.

Notes: Keep the hydrogen outlet clear to prevent production from stopping.
