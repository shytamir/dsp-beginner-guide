# PHASES/YELLOW

2 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [YELLOW 20/min - standard](01-yellow-standard.md)
- [YELLOW 20/min - organic crystals + kimberlite](02-yellow-rare.md)
