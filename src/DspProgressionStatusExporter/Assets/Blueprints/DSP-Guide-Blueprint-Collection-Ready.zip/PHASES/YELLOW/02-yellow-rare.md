# YELLOW 20/min - organic crystals + kimberlite

[Blueprint text](02-yellow-rare.txt) · [Layout preview](previews/02-yellow-rare.png)

Inputs: Kimberlite 10/m; Organic crystals 20/m; Titanium ore 120/m.

Outputs: Yellow cubes 20/m.
