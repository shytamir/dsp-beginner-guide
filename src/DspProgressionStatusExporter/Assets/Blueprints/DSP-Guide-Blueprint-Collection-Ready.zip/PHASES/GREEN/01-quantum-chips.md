# GREEN quantum chips - 20 per min

[Blueprint text](01-quantum-chips.txt) · [Layout preview](previews/01-quantum-chips.png)

Inputs: Processors 40/m; Titanium crystals 40/m; Graphene 80/m; Hydrogen 480/m; Stone 160/m; Titanium ore 160/m; Water 80/m.

Outputs: Quantum chips 20/m.

Notes: Supply both hydrogen inputs at 240/m each. Combine quantum chips with graviton lenses in separate science labs for green cubes. Stock caps: Quantum chips 400.
