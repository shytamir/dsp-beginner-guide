# GREEN lenses 20 and surplus fuel 4 per min

[Blueprint text](02-graviton-lenses.txt) · [Layout preview](previews/02-graviton-lenses.png)

Inputs: Coal 164/m; Turbines 84/m; Copper ore 80/m; Graphene 80/m; Iron ore 46/m; Hydrogen 480/m; Titanium alloy 2/m.

Outputs: Graviton lenses 20/m; Deuteron fuel rods 4/m.

Notes: Supply both hydrogen inputs at 240/m each. Combine graviton lenses with quantum chips in separate science labs for green cubes. Send deuterium overflow to storage; do not return it ahead of the fuel-rod feed. Stock caps: Graviton lenses 200; Deuteron fuel rods 60.
