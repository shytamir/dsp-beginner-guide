# PHASES/GREEN

2 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [GREEN quantum chips - 20 per min](01-quantum-chips.md)
- [GREEN lenses 20 and surplus fuel 4 per min](02-graviton-lenses.md)
