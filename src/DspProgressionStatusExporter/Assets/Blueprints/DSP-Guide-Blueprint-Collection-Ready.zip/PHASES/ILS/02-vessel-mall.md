# Vessels 0.5/min - shared auxiliaries

[Blueprint text](02-vessel-mall.txt) · [Layout preview](previews/02-vessel-mall.png)

Inputs: Titanium alloy 10/m; Processors 5/m; Turbines 5/m.

Outputs: Vessels 0.5/m.
