# PHASES/ILS

2 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [ILS 0.2/min - shared auxiliaries](01-ils-mall.md)
- [Vessels 0.5/min - shared auxiliaries](02-vessel-mall.md)
