# ILS 0.2/min - shared auxiliaries

[Blueprint text](01-ils-mall.txt) · [Layout preview](previews/01-ils-mall.png)

Inputs: Iron ore 24/m; Titanium ore 16/m; Processors 8/m; Particle containers 8/m; Titanium alloy 8/m.

Outputs: ILS 0.2/m.
