# DYSON 405 sails per min + capped ejector mall

[Blueprint text](01-sails-and-ejectors.txt) · [Layout preview](previews/01-sails-and-ejectors.png)

Inputs: Graphene 202.5/m; Stone 1215/m; Iron ore 1132.5/m; Copper ore 221.25/m; Processors 15/m; Coal 60/m.

Outputs: Solar sails 405/m; EM-Rail Ejectors 3/m.

Notes: Ejector stock is capped at 60. Both products are available for local and remote supply. Optional: supply Mk.III proliferator. Listed rates exclude its bonus. Load drones/vessels and warpers as needed for logistics.
