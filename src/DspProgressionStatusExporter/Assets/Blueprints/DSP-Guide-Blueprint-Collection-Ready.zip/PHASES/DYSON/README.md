# PHASES/DYSON

1 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [DYSON 405 sails per min + capped ejector mall](01-sails-and-ejectors.md)
