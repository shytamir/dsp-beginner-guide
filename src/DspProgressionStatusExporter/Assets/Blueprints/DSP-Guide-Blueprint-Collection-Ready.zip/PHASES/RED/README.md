# PHASES/RED

4 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [RED science - 40 per min](01-red-science.md)
- [RED security - missile turrets from ores](02-security-turrets.md)
- [RED security - signal towers from stone and ores](03-security-signals.md)
- [RED security - 10 missile sets per min](04-security-missiles.md)
