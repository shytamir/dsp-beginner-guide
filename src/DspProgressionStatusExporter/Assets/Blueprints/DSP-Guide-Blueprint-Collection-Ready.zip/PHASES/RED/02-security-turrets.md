# RED security - missile turrets from ores

[Blueprint text](02-security-turrets.txt) · [Layout preview](previews/02-security-turrets.png)

Inputs: Copper ore 24/m; Iron ore 66/m.

Outputs: Missile turrets 1/m.

Notes: For the initial eight-turret deployment, take eight from storage; the automatic stock cap is 50.
