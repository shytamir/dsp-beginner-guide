# RED security - signal towers from stone and ores

[Blueprint text](03-security-signals.txt) · [Layout preview](previews/03-security-signals.png)

Inputs: Copper ore 13/m; Iron ore 66/m; Stone 156/m.

Outputs: Signal towers 1/m.

Notes: Stock caps: Signal towers 20.
