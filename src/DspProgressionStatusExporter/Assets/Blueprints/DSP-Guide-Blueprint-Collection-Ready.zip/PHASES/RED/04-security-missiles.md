# RED security - 10 missile sets per min

[Blueprint text](04-security-missiles.txt) · [Layout preview](previews/04-security-missiles.png)

Inputs: Coal 60/m; Iron ore 40/m; Copper ore 100/m.

Outputs: Missile sets 10/m.

Notes: Stock caps: Missile sets 200.
