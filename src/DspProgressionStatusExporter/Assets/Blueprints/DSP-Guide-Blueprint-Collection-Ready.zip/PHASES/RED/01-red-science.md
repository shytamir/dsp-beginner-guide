# RED science - 40 per min

[Blueprint text](01-red-science.txt) · [Layout preview](previews/01-red-science.png)

Inputs: Crude oil 180/m; Coal 160/m.

Outputs: Red cubes 40/m; Hydrogen 10/m; Refined oil 180/m.

Notes: Keep refined-oil and hydrogen outlets clear. Hydrogen overflow can rise to 90/m when science stops.
