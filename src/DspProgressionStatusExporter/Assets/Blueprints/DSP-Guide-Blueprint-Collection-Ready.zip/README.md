# DSP guide — blueprint collection

**56 blueprints, all deployed and tested in the owner's playthrough without defects and producing at the desired rates (2026-10-03).** These are practical starting points to learn from and improve as you play.

Choose a blueprint below, open its text file and paste the contents into the game's blueprint import box. Each description lists inputs, outputs and operating notes. All item rates use **/m (per minute)** and exclude proliferation bonuses.

**PHASES** follows the main guide progression. **AUXILIARY** contains shared production lines. **OPTIONAL** contains the extra malls, SPHERE, WARP, logistics and power-transfer builds. Standard and rare-resource variants are separate blueprints. Each factory is a single paste; the two power-transfer terminals belong on their respective planets.

Supply the listed materials and connect power. Keep byproduct outlets clear, including when the main output stops. Stock caps limit stored mall products; belts and machines can hold additional items. For logistics stations, add drones, vessels and warpers as needed. Where optional spraying is available, supply Mk.III proliferator separately.

For **40/m white cubes into research**, use one BLUE science block, one RED, two YELLOW blocks and two PURPLE blocks. Combine the GREEN branches' quantum chips and graviton lenses in separate labs. Shared lines may also feed malls: add their demands when sizing your supply.

## Books


### PHASES/BLUE — 6 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [BLUE Science - 40 per min](PHASES/BLUE/01-blue-science.md) | Blue cubes 40/m | 84 | 16×16 | 1 |
| [BLUE Mall - Belts and Sorters](PHASES/BLUE/02-mall-logistics.md) | Mk.I belts 60/m, Mk.I sorters 30/m | 84 | 18×18 | 1 |
| [BLUE Mall - Boxes and Tanks](PHASES/BLUE/03-mall-storage.md) | Storage Mk.I 5/m, Storage tanks 5/m | 98 | 18×18 | 1 |
| [BLUE Mall - Wind Tesla and Fuel](PHASES/BLUE/04-mall-power.md) | Wind turbines 5/m, Tesla towers 10/m, Combustible units 15/m | 136 | 22×22 | 1 |
| [BLUE Mall - Miners Smelters Assemblers](PHASES/BLUE/05-mall-industry.md) | Mining machines 5/m, Arc smelters 5/m, Mk.I assemblers 5/m | 264 | 26×26 | 2 |
| [BLUE Foundation - 15 per min](PHASES/BLUE/06-foundation.md) | Foundation 15/m | 50 | 18×18 | 1 |

### PHASES/RED — 4 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [RED science - 40 per min](PHASES/RED/01-red-science.md) | Red cubes 40/m | 274 | 30×30 | 2 |
| [RED security - missile turrets from ores](PHASES/RED/02-security-turrets.md) | Missile turrets 1/m | 157 | 24×24 | 2 |
| [RED security - signal towers from stone and ores](PHASES/RED/03-security-signals.md) | Signal towers 1/m | 194 | 26×26 | 2 |
| [RED security - 10 missile sets per min](PHASES/RED/04-security-missiles.md) | Missile sets 10/m | 194 | 26×26 | 2 |

### PHASES/ILS — 2 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [ILS 0.2/min - shared auxiliaries](PHASES/ILS/01-ils-mall.md) | ILS 0.2/m | 185 | 30×24 | 2 |
| [Vessels 0.5/min - shared auxiliaries](PHASES/ILS/02-vessel-mall.md) | Vessels 0.5/m | 72 | 23×17 | 1 |

### PHASES/YELLOW — 2 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [YELLOW 20/min - standard](PHASES/YELLOW/01-yellow-standard.md) | Yellow cubes 20/m | 692 | 46×45 | 3 |
| [YELLOW 20/min - organic crystals + kimberlite](PHASES/YELLOW/02-yellow-rare.md) | Yellow cubes 20/m | 145 | 33×27 | 1 |

### PHASES/PURPLE — 1 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [PURPLE science - 20 per min](PHASES/PURPLE/01-purple-science.md) | Purple cubes 20/m | 1201 | 60×60 | 4 |

### PHASES/GREEN — 2 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [GREEN quantum chips - 20 per min](PHASES/GREEN/01-quantum-chips.md) | Quantum chips 20/m | 961 | 50×61 | 4 |
| [GREEN lenses 20 and surplus fuel 4 per min](PHASES/GREEN/02-graviton-lenses.md) | Graviton lenses 20/m, Deuteron fuel rods 4/m | 1074 | 52×62 | 4 |

### PHASES/DYSON — 1 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [DYSON 405 sails per min + capped ejector mall](PHASES/DYSON/01-sails-and-ejectors.md) | Solar sails 405/m, EM-Rail Ejectors 3/m | 2505 | 127×60 | 4 |

### PHASES/PHOTON — 1 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [PHOTON four receivers to 48 antimatter per min](PHASES/PHOTON/13-photon-antimatter.md) | Antimatter 48/m | 499 | 114×42 | 3 |

### PHASES/WHITE — 1 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [WHITE 40 per min into research](PHASES/WHITE/01-white-40-into-research.md) | White cubes 40/m | 686 | 68×48 | 3 |

### AUXILIARY — 17 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [Mk.III proliferator - 120 per min](AUXILIARY/01-proliferator.md) | Mk.III proliferator 120/m | 968 | 59×49 | 4 |
| [Carbon nanotubes - 120 per min](AUXILIARY/03-nanotubes.md) | Carbon nanotubes 120/m | 366 | 54×28 | 3 |
| [Frame material - 30 per min](AUXILIARY/04-frame-material.md) | Frame material 30/m | 607 | 54×44 | 3 |
| [Deuteron fuel rods - 40 per min](AUXILIARY/06-deuteron-rods.md) | Deuteron fuel rods 40/m | 660 | 42×28 | 3 |
| [GREEN titanium crystals - 40 per min - standard](AUXILIARY/green-03-titanium-crystals-standard.md) | Titanium crystals 40/m | 975 | 52×59 | 4 |
| [GREEN titanium crystals - 40 per min - organic crystals](AUXILIARY/green-04-titanium-crystals-rare.md) | Titanium crystals 40/m | 162 | 36×27 | 2 |
| [Processors 40/min - raw ores](AUXILIARY/ils-03-processors.md) | Processors 40/m | 436 | 57×27 | 3 |
| [Turbines 30/min - raw ores](AUXILIARY/ils-04-turbines.md) | Turbines 30/m | 361 | 38×38 | 3 |
| [Graphene 60/min - standard](AUXILIARY/ils-05-graphene-standard.md) | Graphene 60/m | 294 | 35×33 | 2 |
| [Graphene 60/min - Fire Ice](AUXILIARY/ils-06-graphene-rare.md) | Graphene 60/m | 56 | 30×16 | 1 |
| [Titanium alloy 30/min - standard](AUXILIARY/ils-07-alloy-standard.md) | Titanium alloy 30/m | 509 | 40×40 | 3 |
| [Titanium alloy 30/min - pumped acid](AUXILIARY/ils-08-alloy-rare.md) | Titanium alloy 30/m | 146 | 32×26 | 1 |
| [Particle containers 10/min - standalone standard](AUXILIARY/ils-09-containers-standard.md) | Particle containers 10/m | 479 | 43×42 | 3 |
| [Particle containers 10/min - standalone Fire Ice](AUXILIARY/ils-10-containers-rare.md) | Particle containers 10/m | 360 | 36×38 | 3 |
| [Particle containers 10/min - shared auxiliaries](AUXILIARY/ils-13-containers-shared.md) | Particle containers 10/m | 72 | 30×16 | 1 |
| [PURPLE processors - 45 per min](AUXILIARY/purple-02-processors.md) | Processors 45/m | 542 | 47×47 | 3 |
| [PURPLE broadband - 22.5 per min](AUXILIARY/purple-03-particle-broadband.md) | Broadband 22.5/m | 689 | 46×46 | 3 |

### OPTIONAL — 19 blueprints

| Blueprint / setup | Output or service | Facilities | Grid | MC by count |
|---|---|---:|---|---:|
| [Orbital Collector mall - 1 per 5 min](OPTIONAL/GAS-GIANT/11-orbital-collectors.md) | Orbital Collectors 0.2/m | 614 | 42×32 | 3 |
| [LOGISTICS - distributors and bots](OPTIONAL/LOGISTICS/01-distribution-kit.md) | Distributors 2/m, Bots 8/m | 191 | 24×24 | 2 |
| [LOGISTICS - PLS and drones](OPTIONAL/LOGISTICS/02-planetary-kit.md) | PLS 0.5/m, Drones 10/m | 288 | 30×30 | 2 |
| [LOGISTICS - ILS and vessels](OPTIONAL/LOGISTICS/03-interstellar-kit.md) | ILS 0.2/m, Vessels 1/m | 113 | 18×18 | 1 |
| [LOGISTICS - Mk.I to Mk.III belts](OPTIONAL/LOGISTICS/04-upgrade-belts.md) | Mk.III belts 60/m | 205 | 22×22 | 2 |
| [LOGISTICS - Mk.I to Mk.III sorters](OPTIONAL/LOGISTICS/05-upgrade-sorters.md) | Mk.III sorters 30/m | 130 | 22×22 | 1 |
| [LOGISTICS - Mk.I to Mk.III assemblers](OPTIONAL/LOGISTICS/06-upgrade-assemblers.md) | Mk.III assemblers 1/m | 1227 | 53×53 | 4 |
| [Advanced Miner mall - 1 per 2 min](OPTIONAL/MINING/12-advanced-miners.md) | Advanced Miners 0.5/m | 557 | 45×32 | 3 |
| [Pile sorter mall - 15 per min](OPTIONAL/PILE-SORTER/02-pile-sorter-mall.md) | Pile sorters 15/m | 484 | 40×48 | 3 |
| [Accumulator mall - 10 per min](OPTIONAL/POWER/09-accumulator-mall.md) | Empty accumulators 10/m | 726 | 51×32 | 3 |
| [Energy Exchanger mall - 1 per 2 min](OPTIONAL/POWER/10-exchanger-mall.md) | Energy Exchangers 0.5/m | 348 | 37×27 | 3 |
| [POWER charging terminal - 54 MW](OPTIONAL/POWER/15-power-provider.md) | Full accumulators 6/m | 73 | 42×40 | 1 |
| [POWER balanced receiving terminal - 54 MW](OPTIONAL/POWER/16-power-receiver.md) | Empty accumulators 6/m | 213 | 58×40 | 2 |
| [SPHERE components - 10 per min](OPTIONAL/SPHERE/05-sphere-components.md) | Sphere components 10/m | 790 | 54×56 | 3 |
| [SPHERE carrier rockets - 5 per min](OPTIONAL/SPHERE/07-carrier-rockets.md) | Carrier rockets 5/m | 181 | 30×18 | 2 |
| [SPHERE silo mall - 1 per 5 min](OPTIONAL/SPHERE/08-silo-mall.md) | Launching silos 0.2/m | 223 | 36×20 | 2 |
| [SPHERE rocket launch - 5 per min](OPTIONAL/SPHERE/14-rocket-launch.md) | Launches 5 rockets/m | 65 | 30×30 | 1 |
| [Dedicated ILS warpers - 120 per min](OPTIONAL/WARP/01-dedicated-warpers.md) | Space warpers 120/m | 308 | 52×40 | 3 |
| [WARP Chemical Plant mall - 2 per min](OPTIONAL/WARP/02-chemical-plants.md) | Chemical Plants 2/m | 657 | 44×37 | 3 |
