# AUXILIARY

17 blueprints. All rates exclude proliferation. Recipe research and upstream capacity still apply.

- [Mk.III proliferator - 120 per min](01-proliferator.md)
- [Carbon nanotubes - 120 per min](03-nanotubes.md)
- [Frame material - 30 per min](04-frame-material.md)
- [Deuteron fuel rods - 40 per min](06-deuteron-rods.md)
- [GREEN titanium crystals - 40 per min - standard](green-03-titanium-crystals-standard.md)
- [GREEN titanium crystals - 40 per min - organic crystals](green-04-titanium-crystals-rare.md)
- [Processors 40/min - raw ores](ils-03-processors.md)
- [Turbines 30/min - raw ores](ils-04-turbines.md)
- [Graphene 60/min - standard](ils-05-graphene-standard.md)
- [Graphene 60/min - Fire Ice](ils-06-graphene-rare.md)
- [Titanium alloy 30/min - standard](ils-07-alloy-standard.md)
- [Titanium alloy 30/min - pumped acid](ils-08-alloy-rare.md)
- [Particle containers 10/min - standalone standard](ils-09-containers-standard.md)
- [Particle containers 10/min - standalone Fire Ice](ils-10-containers-rare.md)
- [Particle containers 10/min - shared auxiliaries](ils-13-containers-shared.md)
- [PURPLE processors - 45 per min](purple-02-processors.md)
- [PURPLE broadband - 22.5 per min](purple-03-particle-broadband.md)
