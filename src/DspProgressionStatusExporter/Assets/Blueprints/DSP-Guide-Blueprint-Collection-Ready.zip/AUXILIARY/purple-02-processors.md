# PURPLE processors - 45 per min

[Blueprint text](purple-02-processors.txt) · [Layout preview](previews/purple-02-processors.png)

Inputs: Iron ore 90/m; Copper ore 135/m; Silicon ore 360/m.

Outputs: Processors 45/m.

Notes: Stock caps: Processors 400.
