# Particle containers 10/min - standalone Fire Ice

[Blueprint text](ils-10-containers-rare.txt) · [Layout preview](previews/ils-10-containers-rare.png)

Inputs: Iron ore 200/m; Copper ore 60/m; Fire ice 20/m.

Outputs: Particle containers 10/m; Hydrogen 10/m.

Notes: Keep the hydrogen outlet clear to prevent production from stopping.
