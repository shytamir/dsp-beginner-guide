# Frame material - 30 per min

[Blueprint text](04-frame-material.txt) · [Layout preview](previews/04-frame-material.png)

Inputs: Graphene 180/m; Titanium ore 120/m; Titanium alloy 30/m; Silicon ore 60/m.

Outputs: Frame material 30/m.

Notes: Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
