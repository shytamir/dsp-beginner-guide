# Deuteron fuel rods - 40 per min

[Blueprint text](06-deuteron-rods.txt) · [Layout preview](previews/06-deuteron-rods.png)

Inputs: Titanium alloy 20/m; Deuterium 400/m; Turbines 40/m; Iron ore 60/m; Coal 40/m.

Outputs: Deuteron fuel rods 40/m.

Notes: Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
