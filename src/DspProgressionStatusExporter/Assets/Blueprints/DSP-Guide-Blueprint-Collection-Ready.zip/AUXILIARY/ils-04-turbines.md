# Turbines 30/min - raw ores

[Blueprint text](ils-04-turbines.txt) · [Layout preview](previews/ils-04-turbines.png)

Inputs: Iron ore 300/m; Copper ore 60/m.

Outputs: Turbines 30/m.
