# PURPLE broadband - 22.5 per min

[Blueprint text](purple-03-particle-broadband.txt) · [Layout preview](previews/purple-03-particle-broadband.png)

Inputs: Graphene 67.5/m; Titanium ore 45/m; Silicon ore 90/m; Crude oil 45/m; Coal 45/m.

Outputs: Broadband 22.5/m; Hydrogen 22.5/m.

Notes: Keep hydrogen and refined-oil relief outlets clear; with production stopped and enough crude supplied, relief can reach 30/m hydrogen and 60/m refined oil. Stock caps: Broadband 400.
