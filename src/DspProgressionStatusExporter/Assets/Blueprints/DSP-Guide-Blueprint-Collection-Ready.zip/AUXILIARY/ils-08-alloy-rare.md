# Titanium alloy 30/min - pumped acid

[Blueprint text](ils-08-alloy-rare.txt) · [Layout preview](previews/ils-08-alloy-rare.png)

Inputs: Titanium ore 60/m; Iron ore 90/m; Sulfuric acid 60/m.

Outputs: Titanium alloy 30/m.
