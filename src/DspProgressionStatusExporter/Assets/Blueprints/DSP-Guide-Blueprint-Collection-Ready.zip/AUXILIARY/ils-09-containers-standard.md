# Particle containers 10/min - standalone standard

[Blueprint text](ils-09-containers-standard.txt) · [Layout preview](previews/ils-09-containers-standard.png)

Inputs: Iron ore 200/m; Copper ore 60/m; Coal 60/m; Crude oil 15/m; Stone 20/m; Water 10/m.

Outputs: Particle containers 10/m; Hydrogen 7.5/m.

Notes: Keep the hydrogen outlet clear to prevent production from stopping.
