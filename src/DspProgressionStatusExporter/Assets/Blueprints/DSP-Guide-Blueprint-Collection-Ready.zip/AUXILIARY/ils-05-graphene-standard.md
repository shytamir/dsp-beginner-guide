# Graphene 60/min - standard

[Blueprint text](ils-05-graphene-standard.txt) · [Layout preview](previews/ils-05-graphene-standard.png)

Inputs: Coal 180/m; Crude oil 45/m; Stone 60/m; Water 30/m.

Outputs: Graphene 60/m; Hydrogen 22.5/m.

Notes: Keep the hydrogen outlet clear to prevent production from stopping.
