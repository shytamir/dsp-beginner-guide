# Particle containers 10/min - shared auxiliaries

[Blueprint text](ils-13-containers-shared.txt) · [Layout preview](previews/ils-13-containers-shared.png)

Inputs: Turbines 20/m; Copper ore 20/m; Graphene 20/m.

Outputs: Particle containers 10/m.
