# Graphene 60/min - Fire Ice

[Blueprint text](ils-06-graphene-rare.txt) · [Layout preview](previews/ils-06-graphene-rare.png)

Inputs: Fire ice 60/m.

Outputs: Graphene 60/m; Hydrogen 30/m.

Notes: Keep the hydrogen outlet clear to prevent production from stopping.
