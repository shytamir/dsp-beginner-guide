# GREEN titanium crystals - 40 per min - standard

[Blueprint text](green-03-titanium-crystals-standard.txt) · [Layout preview](previews/green-03-titanium-crystals-standard.png)

Inputs: Crude oil 200/m; Coal 160/m; Water 40/m; Titanium ore 240/m.

Outputs: Titanium crystals 40/m; Hydrogen 100/m.

Notes: Keep hydrogen and refined-oil relief outlets clear; with production stopped and enough crude supplied, relief can reach 105/m hydrogen and 210/m refined oil. Stock caps: Titanium crystals 200.
