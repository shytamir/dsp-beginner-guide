# Titanium alloy 30/min - standard

[Blueprint text](ils-07-alloy-standard.txt) · [Layout preview](previews/ils-07-alloy-standard.png)

Inputs: Titanium ore 60/m; Iron ore 90/m; Crude oil 90/m; Stone 120/m; Water 60/m.

Outputs: Titanium alloy 30/m; Hydrogen 45/m.

Notes: Keep the hydrogen outlet clear to prevent production from stopping.
