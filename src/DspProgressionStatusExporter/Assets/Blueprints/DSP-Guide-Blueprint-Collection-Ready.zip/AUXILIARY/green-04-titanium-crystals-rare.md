# GREEN titanium crystals - 40 per min - organic crystals

[Blueprint text](green-04-titanium-crystals-rare.txt) · [Layout preview](previews/green-04-titanium-crystals-rare.png)

Inputs: Organic crystals 40/m; Titanium ore 240/m.

Outputs: Titanium crystals 40/m.

Notes: Stock caps: Titanium crystals 200.
