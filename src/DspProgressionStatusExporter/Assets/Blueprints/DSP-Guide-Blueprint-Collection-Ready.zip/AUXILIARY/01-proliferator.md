# Mk.III proliferator - 120 per min

[Blueprint text](01-proliferator.txt) · [Layout preview](previews/01-proliferator.png)

Inputs: Coal 960/m; Graphene 180/m; Titanium ore 120/m.

Outputs: Mk.III proliferator 120/m.
