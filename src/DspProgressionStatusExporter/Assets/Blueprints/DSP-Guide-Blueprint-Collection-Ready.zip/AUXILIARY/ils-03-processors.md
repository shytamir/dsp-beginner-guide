# Processors 40/min - raw ores

[Blueprint text](ils-03-processors.txt) · [Layout preview](previews/ils-03-processors.png)

Inputs: Iron ore 80/m; Copper ore 120/m; Silicon ore 320/m.

Outputs: Processors 40/m.
