# Carbon nanotubes - 120 per min

[Blueprint text](03-nanotubes.txt) · [Layout preview](previews/03-nanotubes.png)

Inputs: Graphene 180/m; Titanium ore 120/m.

Outputs: Carbon nanotubes 120/m.

Notes: Optional: supply Mk.III proliferator. Listed rates exclude its bonus.
